﻿$(document).ready(function () {
    $('#loader').hide();
   
});
